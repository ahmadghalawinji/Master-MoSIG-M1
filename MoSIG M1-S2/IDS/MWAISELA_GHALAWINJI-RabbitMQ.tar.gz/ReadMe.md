# PART 1 CHAT With RabbitMQ 

This is the chat Application using Rabbitmq.

To compile :
javac -cp ./bin/amqp-client-5.14.2.jar -d ./bin/ ./src/chatApp.java

To run :
1.cd bin
2.java -cp .:amqp-client-5.14.2.jar:slf4j-api-1.7.36.jar:slf4j-simple-1.7.36.jar chatApp <<name>>

Note: name refers to the client name used in the chat and should be unique assigned.

# PART 2 Ring with RabbitMQ 

This part focuses of the ring implementantion

To compile run :
 
javac -cp ./bin/amqp-client-5.14.2.jar -d ./bin/ ./src/ring.java

To run :
cd bin
java -cp .:amqp-client-5.14.2.jar:slf4j-api-1.7.36.jar:slf4j-simple-1.7.36.jar ring <<number of nodes>>