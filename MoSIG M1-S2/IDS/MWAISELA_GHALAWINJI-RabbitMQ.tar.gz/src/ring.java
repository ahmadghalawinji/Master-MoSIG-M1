import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Lock;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;
import java.nio.charset.StandardCharsets;

class nodes extends Thread {

    String id;
    int node;
    String token = "token";

    public nodes(String id, int node) {
        this.id = id;
        this.node = node;
    }

    @Override
    public void run() {
        try {

            ConnectionFactory factory = new ConnectionFactory();
            factory.setHost("localhost");
            Connection connection = factory.newConnection();
            Channel channel = connection.createChannel();

            channel.exchangeDeclare("ringExchange", "direct");
            String queueName = channel.queueDeclare().getQueue();
            channel.queueBind(queueName, "ringExchange", id);

            DeliverCallback deliverCallback = (consumerTag, delivery) -> {
                String message = new String(delivery.getBody(), "UTF-8");

                if (message.equals(token) && id.equals("1")) {
                    System.out.println("Node " + id + " Received " + token + " and halts");
                    System.exit(0);
                }
                System.out.println("Node " + id + " Received " + token);
                if (Integer.parseInt(id) == node) {
                    channel.basicPublish("ringExchange",
                            "1", null,
                            token.getBytes("UTF-8"));

                } else {
                    channel.basicPublish("ringExchange",
                            String.valueOf(Integer.parseInt(id) + 1), null,
                            token.getBytes("UTF-8"));
                }

            };
            if (id.equals("1")) {
                System.out.println("Node " + id + " initiates and send the token " + token);
                channel.basicPublish("ringExchange",
                        String.valueOf(Integer.parseInt(id) + 1), null,
                        token.getBytes("UTF-8"));
            }
            channel.basicConsume(queueName, true, deliverCallback, consumerTag -> {
            });

        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }

    }
}

public class ring {

    public static void main(String args[]) {

        
        if (args.length < 1 || Integer.parseInt(args[0]) <= 1) {
            System.out.println("Usage: chatClient <<number of nodes for ring>>");
            System.exit(1);
        }
        int node = Integer.parseInt(args[0]);
        for (int i = 0; i < node; i++) {
            nodes object = new nodes(String.valueOf(i + 1), node);
            object.start();

        }

    }

}