import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.rmi.*;
import java.util.ArrayList;
import java.util.Iterator;

public class chatImpl implements chat {
    ArrayList<chatRoom> chatRooms;

    public chatImpl() {
        File file = new File("files/messages.ser");
        if (!file.exists()) {
            chatRooms = new ArrayList<chatRoom>();
            chatRooms.add(new chatRoom("Distributed System"));
            chatRooms.add(new chatRoom("Robotics"));
            chatRooms.add(new chatRoom("Operating System"));
        } else {
            try {
                FileInputStream readData = new FileInputStream(file);
                ObjectInputStream readStream = new ObjectInputStream(readData);
                chatRooms = (ArrayList<chatRoom>) readStream.readObject();

                for(int i=0;i<chatRooms.size();i++){
                    chatRooms.get(i).nulifyClients();
                }
                readStream.close();
            } catch (Exception e) {

                e.printStackTrace();

            }
        }

    }

    private chatRoom find(String name) {

        Iterator<chatRoom> roomsIterator = chatRooms.iterator();
        chatRoom room;
        while (roomsIterator.hasNext()) {
            room = roomsIterator.next();
            if (room.getRoomName().equals(name)) {
                return room;
            }
        }
        return null;
    }

    public boolean joinChat(clientRoom client, String roomName) throws RemoteException {
        chatRoom rooms = find(roomName);
        if (rooms != null) {
            rooms.addClient(client);
            rooms.notifyAll(client.getName() + "  joined !!");
            saveState();
            return true;
        }
        client.displayClientMessages("No such room Available", null);
        return false;
    }

    public boolean leaveChat(clientRoom client, String roomName) throws RemoteException {

        chatRoom rooms = find(roomName);
        if (rooms != null) {
            rooms.removeClient(client);
            rooms.notifyAll(client.getName() + " left !!");
            saveState();
            return true;
        }
        return false;
    }

    public void send(String message, clientRoom client, String roomName) throws RemoteException {

        chatRoom rooms = find(roomName);
        if (rooms.checkClient(client) && message != null) {
            rooms.notifyAll(client.getName() + ": " + message);
            saveState();
        }
    }

    public ArrayList<String> getChatRooms() throws RemoteException {
        ArrayList<String> names = new ArrayList<String>();
        for (int i = 0; i < chatRooms.size(); i++) {
            names.add(chatRooms.get(i).getRoomName());
        }
        return names;
    }

    public ArrayList<String> registeredChat(clientRoom client) throws RemoteException {

        ArrayList<String> registeredRooms = new ArrayList<>();
        Iterator<chatRoom> roomsIterator = chatRooms.iterator();
        chatRoom room;
        while (roomsIterator.hasNext()) {
            room = roomsIterator.next();
            if (room.checkClient(client)) {
                registeredRooms.add(room.getRoomName());
            }
        }
        return registeredRooms;
    }

    public void restoreState(clientRoom client) throws RemoteException {
        Iterator<chatRoom> roomsIterator = chatRooms.iterator();
        while (roomsIterator.hasNext()) {
            roomsIterator.next().restoreClient(client);
        }
    }

    private void saveState() {
        try {
            FileOutputStream writeData = new FileOutputStream(
                    "files/messages.ser");
            ObjectOutputStream writeStream = new ObjectOutputStream(writeData);
            writeStream.writeObject(chatRooms);
            writeStream.flush();
            writeStream.close();

        } catch (Exception e) {
            System.out.println("Error on Saving data : " + e);
            e.printStackTrace();
        }

    }
}
