import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class chatRoom implements Serializable {
    private String name;
    private Map<String, clientRoom> usersList;
    private ArrayList<String> messagesArrayList;

    public chatRoom(String n) {
        usersList = new HashMap<>();
        messagesArrayList = new ArrayList<String>();
        name = n;
    }

    public String getRoomName() {
        return name;
    }

    public void addClient(clientRoom client) throws RemoteException {
        for (int i = 0; i < messagesArrayList.size(); i++) {
            client.displayClientMessages(messagesArrayList.get(i), name);
        }
        usersList.put(client.getName(), client);
    }

    public void removeClient(clientRoom client) throws RemoteException {
        usersList.remove(client.getName());
    }

    public boolean checkClient(clientRoom client) throws RemoteException {
        return usersList.containsKey(client.getName());
    }

    public void notifyAll(String message) throws RemoteException {

        for (clientRoom client : usersList.values()) {
            if (client != null) {
                client.displayClientMessages(message, name);
            }

        }
        messagesArrayList.add(message);
    }

    public void restoreClient(clientRoom client) throws RemoteException {
        usersList.replace(client.getName(), client);
        if (usersList.containsKey(client.getName())) {
            for (int i = 0; i < messagesArrayList.size(); i++) {
                client.displayClientMessages(messagesArrayList.get(i), name);
            }
        }
    }

    public void nulifyClients() {
        for (String clientName : usersList.keySet()) {
            usersList.replace(clientName, null);
        }

    }
}
