import java.rmi.*;
import java.rmi.server.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.rmi.registry.*;

public class chatClient {

    public static void main(String[] args) {
        try {
            // if (args.length < 1) {
            // System.out.println("Usage: java ChatClient <rmiregistry host> Name");
            // return;
            // }
            // String host = args[0];
            // String name = args[1];

            // starting GUI
            clientGUI display = new clientGUI();

            clientRoomImp client = new clientRoomImp(display);

            if (display.getName().isEmpty() || display.getName() == null || display.getNetworkAddr().isEmpty()
                    || display.getNetworkAddr() == null) {
                return;
            }

            clientRoom client_stub = (clientRoom) UnicastRemoteObject.exportObject(client, 0);

            Registry registry = LocateRegistry.getRegistry(display.getNetworkAddr());
            chat Chat = (chat) registry.lookup("chatService");

            // Restore states in server
            Chat.restoreState(client_stub);

            // Scanner input = new Scanner(System.in);

            // // ArrayList<String> chatRooms = Chat.getChatRooms();
            // // String roomName;
            // // int choice;

            display.setServerRef(Chat, client_stub);
            display.showGUI();

            // while (true) {
            // System.out.println("Enter 6 for help");
            // choice = input.nextInt();
            // input.nextLine();
            // switch (choice) {
            // case 1:
            // System.out.println("Enter Chat Room Name");
            // roomName = input.nextLine();
            // Chat.joinChat(client_stub, roomName);
            // break;
            // case 2:
            // System.out.println("Enter Chat Room Name");
            // roomName = input.nextLine();
            // System.out.println("Enter message");
            // String message = input.nextLine();
            // Chat.send(message, client_stub, roomName);
            // break;
            // case 3:
            // System.out.println("Enter Chat Room Name");
            // roomName = input.nextLine();
            // Chat.leaveChat(client_stub, roomName);

            // break;
            // case 4:
            // Chat.registeredChat(client_stub);
            // break;
            // case 5:
            // for (int i = 0; i < chatRooms.size(); i++) {
            // System.out.println(i + ": " + chatRooms.get(i));
            // }
            // break;
            // case 6:
            // System.out.println("Help:");
            // System.out.println("1.Join Chat");
            // System.out.println("2.Send Message");
            // System.out.println("3.Leave Chat");
            // System.out.println("4.List Chat Rooms Joined");
            // System.out.println("5.List Chat Rooms Available On Server");
            // break;

            // default:
            // System.out.println("No such operation Available");
            // break;
            // }
            // }
        } catch (Exception e) {

            System.out.println("Error on client :" + e);
        }
    }
}
