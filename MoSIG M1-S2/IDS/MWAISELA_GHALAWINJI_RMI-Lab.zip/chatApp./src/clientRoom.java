import java.rmi.*;

public interface clientRoom extends Remote {

    public void displayClientMessages(String message, String group) throws RemoteException;

    public String getName() throws RemoteException;

}
