import java.io.Serializable;
import java.rmi.RemoteException;

public class clientRoomImp implements clientRoom, Serializable {
    private String name;
    private clientGUI client;

    public clientRoomImp(clientGUI client) {
        name = client.getClientName();
        this.client = client;
    }

    public void displayClientMessages(String message, String group) throws RemoteException {
        System.out.println(message);
        client.sendMessage(message, group);
    }

    public String getName() throws RemoteException {
        return name;
    }

}
