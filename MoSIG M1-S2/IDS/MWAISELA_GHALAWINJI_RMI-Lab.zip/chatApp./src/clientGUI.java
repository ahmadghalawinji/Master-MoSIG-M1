import java.awt.Color;
import java.awt.event.*;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.awt.*;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class clientGUI extends JFrame {

    static JPanel background, leftPanel, chatPanel, messagePanel, displayMessages_robotics,
            displayMessage_OS,
            displayMessage_distributed, welcomePanel;
    static JButton send, joinButton, leaveButton;
    static JFrame frame;
    static JTextField messageField, requestName, requestAddress;
    static JLabel groupAvaJLabel, groupJLabel, jTextField, jTextField2, space;
    static JList listJoined;
    static JTextArea messagePanel_robot, messagePanel_OS, messagePanel_distributed;
    static ImageIcon iconSend;
    static JScrollPane scroll_robot, scroll_messagePanel_OS, scroll_messagePanel_distributed;
    DefaultListModel groupJoinedList;
    ArrayList<String> groups;
    String clientName, networkAddr;
    String groupJoined;
    chat Chat;
    clientRoom client_stub;

    public clientGUI() {
        groupJoinedList = new DefaultListModel();
        groupAvaJLabel = new JLabel("  ");
        jTextField2 = new JLabel("  ");
        space = new JLabel("  ");
        groupJLabel = new JLabel("Chat Groups:");
        messagePanel = new JPanel(new BorderLayout());

        // request for name and Address ie Log in
        requestName = new JTextField(10);
        requestAddress = new JTextField(10);
        JPanel requestPanel = new JPanel();
        requestPanel.add(new JLabel("name:"));
        requestPanel.add(requestName);
        requestPanel.add(Box.createHorizontalStrut(15));
        requestPanel.add(new JLabel("Network address:"));
        requestPanel.add(requestAddress);

        messagePanel_robot = new JTextArea();
        messagePanel_robot.setEditable(false);
        messagePanel_robot.setLineWrap(true);
        scroll_robot = new JScrollPane(messagePanel_robot);
        displayMessages_robotics = new JPanel(new BorderLayout());
        displayMessages_robotics.add(scroll_robot, BorderLayout.CENTER);
        messagePanel_robot.setLayout(new BoxLayout(messagePanel_robot, BoxLayout.Y_AXIS));

        displayMessage_OS = new JPanel(new BorderLayout());
        messagePanel_OS = new JTextArea();
        messagePanel_OS.setEditable(false);
        messagePanel_OS.setLineWrap(true);
        scroll_messagePanel_OS = new JScrollPane(messagePanel_OS);
        displayMessage_OS.add(scroll_messagePanel_OS, BorderLayout.CENTER);
        messagePanel_OS.setLayout(new BoxLayout(messagePanel_OS, BoxLayout.Y_AXIS));

        messagePanel_distributed = new JTextArea();
        messagePanel_distributed.setEditable(false);
        messagePanel_distributed.setLineWrap(true);
        scroll_messagePanel_distributed = new JScrollPane(messagePanel_distributed);
        displayMessage_distributed = new JPanel(new BorderLayout());
        displayMessage_distributed.add(scroll_messagePanel_distributed, BorderLayout.CENTER);
        messagePanel_distributed.setLayout(new BoxLayout(messagePanel_distributed, BoxLayout.Y_AXIS));

        welcomePanel = new JPanel(new BorderLayout());

        JLabel welcomeLabel = new JLabel("Select Chat to display here !!", JLabel.CENTER);
        welcomePanel.add(welcomeLabel);

        frame = new JFrame();
        background = new JPanel(new BorderLayout());
        leftPanel = new JPanel();

        chatPanel = new JPanel(new CardLayout());
        chatPanel.add(welcomePanel, "WELCOME");
        messageField = new JTextField();
        iconSend = new ImageIcon("files/icons8-send-32.png");
        send = new JButton(iconSend);
        leaveButton = new JButton("Leave Chat");
        joinButton = new JButton("Join Chat");

        int result = JOptionPane.showConfirmDialog(null, requestPanel,
                "Log In", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            clientName = requestName.getText();
            networkAddr = requestAddress.getText();
        }

    }

    public void sendMessage(String message, String groupName) {

        addMessagePanel(groupName, message);
        messageField.setText("");

    }

    public void showGUI() {

        // Setting the background
        background.add(leftPanel, BorderLayout.WEST);
        background.add(chatPanel, BorderLayout.CENTER);

        // Setting the chat Panel
        chatPanel.setBackground(Color.decode("#FFFAFA"));

        // messageField.
        messagePanel.add(messageField, BorderLayout.CENTER);
        messagePanel.setBackground(Color.decode("#FFFAFA"));
        messagePanel.add(send, BorderLayout.EAST);

        // Action Listeners for send and messagefield
        send.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String message = messageField.getText();
                    String selected = listJoined.getSelectedValue().toString();
                    Chat.send(message, client_stub, selected);
                } catch (RemoteException e1) {

                    e1.printStackTrace();
                }
                ;

            }
        });

        leaveButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Object selected = listJoined.getSelectedValue();
                    if (selected != null) {
                        Chat.leaveChat(client_stub, selected.toString());
                        groupJoinedList.removeElement(selected.toString());
                        CardLayout cl = (CardLayout) (chatPanel.getLayout());
                        cl.show(chatPanel, "WELCOME");

                    }

                } catch (RemoteException e1) {
                    e1.printStackTrace();

                }

            }

        });

        // Setting the left panel
        leftPanel.setBackground(Color.decode("#2F4F4F"));
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.add(groupAvaJLabel);
        groupAvaJLabel.setAlignmentX(CENTER_ALIGNMENT);
        groupAvaJLabel.setForeground(Color.WHITE);
        leftPanel.add(joinButton);
        joinButton.setAlignmentX(CENTER_ALIGNMENT);
        groupJLabel.setAlignmentX(CENTER_ALIGNMENT);
        leftPanel.add(Box.createVerticalGlue());
        leftPanel.add(groupJLabel);
        leftPanel.add(space);
        groupJLabel.setForeground(Color.WHITE);
        leftPanel.add(listJoined);
        leftPanel.add(Box.createVerticalGlue());
        leftPanel.add(leaveButton);
        leaveButton.setAlignmentX(CENTER_ALIGNMENT);
        leftPanel.add(jTextField2);

        joinButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                groupJoined = (String) JOptionPane.showInputDialog(frame, "Select the Chat to Join", clientName,
                        JOptionPane.PLAIN_MESSAGE,
                        new ImageIcon(), groups.toArray(), "--Select");
                try {
                    if (groupJoined != null && !groupJoinedList.contains(groupJoined)) {
                        Chat.joinChat(client_stub, groupJoined);
                        groupJoinedList.addElement(groupJoined);
                        addPanel(groupJoined);

                        groupJoined = null;
                    }

                } catch (RemoteException e1) {
                    e1.printStackTrace();
                }
            }
        });

        listJoined.setBackground(Color.decode("#2F4F4F"));
        listJoined.setForeground(Color.WHITE);

        // Setting the frame
        frame.add(background);
        frame.setSize(500, 500);
        frame.setVisible(true);

    }

    public String getClientName() {
        return clientName;
    }

    public String getNetworkAddr() {
        return networkAddr;
    }

    public void setServerRef(chat Chat, clientRoom client_stub) throws RemoteException {
        this.client_stub = client_stub;
        this.Chat = Chat;
        groups = Chat.getChatRooms();
        groupJoinedList.addAll(Chat.registeredChat(client_stub));
        listJoined = new JList(groupJoinedList);

        if (!groupJoinedList.isEmpty()) {
            for (int i = 0; i < groupJoinedList.size(); i++)
                addPanel(groupJoinedList.get(i).toString());

        }

        listJoined.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                Object selected = listJoined.getSelectedValue();
                if (selected != null) {
                    CardLayout cl = (CardLayout) (chatPanel.getLayout());
                    cl.show(chatPanel, (String) selected);
                    getPanel(selected.toString()).add(messagePanel, BorderLayout.SOUTH);
                }

            }
        });
    }

    private void addPanel(String groupAdd) {
        if (groupAdd.equals("Distributed System")) {
            chatPanel.add(displayMessage_distributed, "Distributed System");

        } else if (groupAdd.equals("Robotics")) {
            chatPanel.add(displayMessages_robotics, "Robotics");

        } else if (groupAdd.equals("Operating System")) {
            chatPanel.add(displayMessage_OS, "Operating System");

        }
    }

    private JPanel getPanel(String group) {
        if (group.equals("Distributed System")) {
            return displayMessage_distributed;
        } else if (group.equals("Robotics")) {
            return displayMessages_robotics;
        } else if (group.equals("Operating System")) {
            return displayMessage_OS;

        } else
            return null;
    }

    private void addMessagePanel(String panel, String message) {

        if (panel.equals("Distributed System")) {
            if (messagePanel_distributed.getText().equals("")) {
                messagePanel_distributed.setText(" " + message + "\n\n");
            } else {
                messagePanel_distributed.append(" " + message + "\n\n");
            }

        } else if (panel.equals("Robotics")) {
            if (messagePanel_robot.getText().equals("")) {
                messagePanel_robot.setText(message + "\n\n");
            } else {
                messagePanel_robot.append(message + "\n\n");
            }

        } else if (panel.equals("Operating System")) {
            if (messagePanel_OS.getText().equals("")) {
                messagePanel_OS.setText(message + "\n\n");
            } else {
                messagePanel_OS.append(message + "\n\n");
            }

        }
    }

}
