import java.rmi.*;
import java.util.ArrayList;

public interface chat extends Remote {
    public boolean joinChat(clientRoom client, String roomName) throws RemoteException;

    public boolean leaveChat(clientRoom client, String roomName) throws RemoteException;

    public void send(String message, clientRoom client, String roomName) throws RemoteException;

    public ArrayList<String> getChatRooms() throws RemoteException;

    public ArrayList<String> registeredChat(clientRoom client) throws RemoteException;

    public void restoreState(clientRoom client) throws RemoteException;

}
