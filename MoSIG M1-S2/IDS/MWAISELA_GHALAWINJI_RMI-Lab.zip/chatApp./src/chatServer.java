import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

public class chatServer {

    public static void main(String[] args) {
        try {

            chatImpl Chat = new chatImpl();
            chat chat_stub = (chat) UnicastRemoteObject.exportObject(Chat, 0);
            LocateRegistry.createRegistry(1099);
            Registry registry = LocateRegistry.getRegistry();

            registry.rebind("chatService", chat_stub);
        
            System.out.println("Server ready");
        } catch (Exception e) {
            System.out.println("Error on server :" + e);
            e.printStackTrace();
        }

    }

}
