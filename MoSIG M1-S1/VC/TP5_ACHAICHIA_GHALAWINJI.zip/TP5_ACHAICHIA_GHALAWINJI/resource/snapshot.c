#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "imageFormationUtils.h"
#include "Util.h"

int
main(int argc, char* argv[])
{
  FILE* ofp;
  if (argc != 3){
    printf("\nUsage: %s file f\n\n", argv[0]);
    exit(1);
  }
  int i, j, c, u, v;
  float f, tempx, tempy, tempz;
  float alphav = 0.005;
  float alphau = 0.005;
  int dimx = 500;
  int dimy = 500;
  int v0 = dimx/2;
  int u0 = dimy/2;
  struct point3d *points;
  int N_v = 0;
  f = atof(argv[2]);
  points = readOff(argv[1], &N_v);
  centerThePCL(points, N_v);

  float TransMatrix[16];
//  computeTrans(0.1, 1.74, 0.2, 0, 0.52, 0.15, TransMatrix);
  computeTrans(0, 0, 0, 0, 0, 0, TransMatrix);

  for (i=0; i<N_v; i++){
    tempx = TransMatrix[0]*points[i].x + TransMatrix[1]*points[i].y
        + TransMatrix[2]*points[i].z + TransMatrix[3]*1;
    tempy = TransMatrix[4]*points[i].x + TransMatrix[5]*points[i].y
        + TransMatrix[6]*points[i].z + TransMatrix[7]*1;
    tempz = TransMatrix[8]*points[i].x + TransMatrix[9]*points[i].y
        + TransMatrix[10]*points[i].z + TransMatrix[11]*1;
    if (f != 0){
      points[i].x = tempx/(1+tempz/f);
      points[i].y = tempy/(1+tempz/f);
      points[i].z = 0;
    }
    else{
      points[i].x = tempx;
      points[i].y = tempy;
      points[i].z = tempz;
    }
  }
  pix* pixmap = (pix*)malloc(dimx*dimy*3*sizeof(pix));
  for (i=0; i<dimx; i++)
    for (j=0; j<dimy; j++)
      for (c=0; c<3; c++)
        pixmap[i*dimy*3 + j*3 + c] = 50;
  for (i=0; i<N_v; i++){
    u = ((int)(points[i].x/alphau)) + u0;
    v = ((int)(points[i].y/alphav)) + v0;
    if (u < dimx && u >= 0)
      if (v < dimy && v >= 0){
        pixmap[u * dimy*3 + v * 3] = (char)points[i].r;
        pixmap[u * dimy*3 + v * 3+1] = (char)points[i].g;
        pixmap[u * dimy*3 + v * 3+2] = (char)points[i].b;
      }
  }

  ofp = fopen("snapshot.ppm", "w");
  fprintf(ofp,"P6\n");

    fprintf(ofp,"%d %d\n", dimx, dimy);
    fprintf(ofp,"%d\n",255);

  for(i=0; i < dimx; i++)
    for(j=0; j < dimy ; j++){
      fprintf(ofp,"%c", pixmap[i*dimy*3 + j*3]);
      fprintf(ofp,"%c", pixmap[i*dimy*3 + j*3 + 1]);
      fprintf(ofp,"%c", pixmap[i*dimy*3 + j*3 + 2]);
    }
}
